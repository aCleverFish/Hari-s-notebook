module.exports = {
  title: '代码重工',
  description: '代码重工',
  base: '/code_heavy_industry/',
  markdown: {
    lineNumbers: true
  }
}